Devoir 1 : l'algorithme d'Aho et Corasick

LACHTER Nazim
LAUZIER Maëva

Exécuter le programme directement avec le fichier JAR intégré : Trie.jar.
Les fichiers du projet sont intégrés dans ce dernier.

Le but du programme est de rechercher chacun des mots contenus dans "cyranoDict.txt", dans le fichier "1256-0.txt".
Il donnera la position de ce qu'il trouve en nombre de caractères depuis le début du fichier.
