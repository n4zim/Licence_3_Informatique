# TP04 - Analyse syntaxique
 
LACHTER feat. PETITEAU

Pour lancer le programme, le fichier make a été mis à jour.
Il suffit donc de lancer la commande pour compiler le programme.

Pour l'éxécuter, il s'agit de lancer le fichier ./test_yylex
Le répértoire contenant les tests est "Tests".

Un test volontairement erroné a été créé pour tester
    l'analyseur : boucle_error.l
  
Exemples de commandes d'éxécution :
	./test_yylex Tests/boucle.l
	./test_yylex Tests/boucle_error.l
