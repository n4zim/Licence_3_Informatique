 == TP02 - Analyse syntaxique des expressions ==
 
LACHTER feat. PETITEAU

Pour lancer le programme, un fichier make a été mis à jour.
Il suffit donc de lancer la commande pour compiler le programme.

Pour l'éxécuter, il s'agit de lancer le fichier ./test_yylex
Le répértoire contenant les tests (pour l'instant il n'y en a qu'un (celui du TP))
  est "Tests_syntaxe".
  
Commande d'éxécution : ./test_yylex Tests_syntaxe/Operation.l