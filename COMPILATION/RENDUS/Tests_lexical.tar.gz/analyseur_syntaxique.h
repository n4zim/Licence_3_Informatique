#ifndef __ANALYSEUR_SYNTAXIQUE__
#define __ANALYSEUR_SYNTAXIQUE__

#include "stdio.h"

void analyseur_syntaxique(void);
void E(void);
void Ep(void);
void T(void);
void Tp(void);
void F(void);

#endif