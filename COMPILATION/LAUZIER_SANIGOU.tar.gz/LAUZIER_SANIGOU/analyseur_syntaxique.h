void Eprim(void);
void T(void);
void Tprim(void);
void F(void);
void E(void);
void analyseur_syntaxique(int uc);