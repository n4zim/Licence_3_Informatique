
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "cpu.h"
#include "systeme.h"

#define MAX_PROCESS (20) /* nb maximum de processus */
#define EMPTY (0) /* processus non-pret */
#define READY (1) /* processus pret */
#define SLEEP (2) /* processus ronpiissshhhhhh */
#define GETCHAR (3)
#define FALSE 0
#define TRUE 1

struct {
	PSW cpu; /* mot d’etat du processeur */
	int state; /* etat du processus */
	int case_mem;
}	process[MAX_PROCESS]; /* table des processus */

int tab_used_mem[6] = {0, 0, 0, 0, 0, 0};
int current_process = -1; /* nu du processus courant */
int count_getchar = 0;
time_t sleeping_process[MAX_PROCESS];

char tampon = '\0'; /* le ’\0’ indique le vide */


/**********************************************************
** Demarrage du systeme
***********************************************************/

static PSW systeme_init(void) {
	PSW cpu;

	process [0].cpu = cpu;
	process [0].state = READY;
	process [0].case_mem = 0;
	current_process = 0;
	tab_used_mem[0] = TRUE;
	
	process [1].cpu = cpu;
	process [1].state = READY;
	process [1].case_mem = 1;
	tab_used_mem[1] = TRUE;
	current_process = 1;
	
	printf("Booting.\n");
	/*** creation d'un programme ***/
	make_inst(0, INST_SUB, 2, 2, -1000); /* R2 -= R2-1000 */
	make_inst(1, INST_ADD, 1, 2, 500);   /* R1 += R2+500 */
	make_inst(2, INST_ADD, 0, 2, 200);   /* R0 += R2+200 */
	make_inst(3, INST_ADD, 0, 1, 100);   /* R0 += R1+100 */
	//make_inst(0, INST_SYSC, 2, 1, SYSC_PUTI);   /* R0 += R1+100 */
	
	/*** valeur initiale du PSW ***/
	memset (&cpu, 0, sizeof(cpu));
	cpu.PC = 0;
	cpu.SB = 0;
	cpu.SS = 20;

	return cpu;
}


/**********************************************************
** Simulation du systeme (mode systeme)
***********************************************************/

PSW ordonnanceur (PSW m) {
	if (current_process == -1)  {
		process [0].cpu = m;
		current_process = 0;
	} else 
		process [current_process].cpu = m;
	do {
		printf ("COUCOU JE SUIS PROCESS %d\n", current_process);
		current_process = (current_process + 1) % MAX_PROCESS;
		if (process[current_process].state == SLEEP)
			if(sleeping_process[current_process] - time(NULL) < 0)
				process[current_process].state = READY;
			
	} while (process[current_process].state != READY);
	m = process [current_process].cpu;
	return m;
}

void printDR (PSW m) {
	for (int i = 0; i < 8 ; i ++) {
		printf ("DR[%d] : 	%d\n", i, m.DR[i]);
	}
}

PSW new_thread (PSW m) {
	int new_index = (current_process + 1) % MAX_PROCESS;
	process[new_index].cpu = m;
	process[new_index].cpu.RI.i = 0;
	process[new_index].cpu.AC = 0;
	m.RI.i = current_process;
	m.AC = current_process;
	return m;
}

PSW sleep(PSW m){
	time_t date_reveil = m.RI.i + time(NULL); 
	process[current_process].state = SLEEP;
	sleeping_process[current_process] = date_reveil;
	return m;
}

PSW sys_getchar(PSW m){
	if (tampon == '\0') {
		process[current_process].state = GETCHAR;
		count_getchar ++;
		m = ordonnanceur(m);
	} else {
		process[current_process].state = READY;
		m.RI.i = tampon; 
		tampon = '\0';
		count_getchar --;
	}
	return m;
}

PSW sys_fork(PSW m){
	int i, j;
	for (i = 0; i < 6; i++) {
		if (tab_used_mem[i] == FALSE) break;
	}
	if (i == 6){
		printf("Erreur! Mémoire Full!!!\n");
		exit(1);
	}

	for(j = 0; j < MAX_PROCESS; j++)
		if(process[j].state == EMPTY) break;

	if (j == MAX_PROCESS){
		printf("Erreur! Max process atteint, fork impossible!!!\n");
		exit(1);
	}

	process [j].cpu = process[current_process].cpu;
	process [j].state = process[current_process].state;
	process [j].case_mem = i;
	current_process++;
	tab_used_mem[i] = TRUE;
	
	return m;
}

PSW appel_systeme(PSW m) {
	switch (m.RI.ARG) {
		case SYSC_EXIT :
			exit (1);
			break;
		case SYSC_PUTI :
			printf ("REG1 : 	%d\n", m.RI.i);
			break;
		case SYSC_NEW_THREAD :
			new_thread(m);
			break;
		case SYSC_SLEEP :
			sleep(m);
			break;
		case SYSC_GETCHAR :
			sys_getchar(m);
			break;
		case SYSC_FORK :
			sys_fork(m);
			break;
		default : 
			break;
	}
	return m;
}

PSW systeme(PSW m) {
	switch (m.IN) {
		case INT_INIT:
			return (systeme_init());
		case INT_SEGV:
			printf("Erreur: adressage mémoire incorrecte\n");
			exit (-1);
			break;
		case INT_TRACE:
			printf("PC : 	%d\n", m.PC);
			printDR(m);
			break;
		case INT_INST:
			printf("Erreur: instruction inconnue\n");
			exit (-1);
			break;
		case INT_CLOCK :
			m = ordonnanceur (m);
			break;
		case INT_SYS : 
			appel_systeme (m);
			break;
	}
	printf ("Code interruption : %d\n", m.IN);
	return m;
}
