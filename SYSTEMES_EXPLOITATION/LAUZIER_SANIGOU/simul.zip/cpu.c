
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "cpu.h"

/**********************************************************
** definition de la memoire simulee
***********************************************************/

WORD mem[128];     /* memoire                       */
int count = 0;


/**********************************************************
** Placer une instruction en memoire
***********************************************************/

void make_inst(int adr, unsigned code, unsigned i, unsigned j, short arg) {
	union { WORD word; INST fields; } inst;
	inst.fields.OP  = code;
	inst.fields.i   = i;
	inst.fields.j   = j;
	inst.fields.ARG = arg;
	mem[adr] = inst.word;
}


INST decode_instruction(WORD value) {
	union { WORD integer; INST instruction; } inst;
	inst.integer = value;
	return inst.instruction;
}


/**********************************************************
** instruction d'addition
***********************************************************/

PSW cpu_ADD(PSW m) {
	m.AC = m.DR[m.RI.i] += (m.DR[m.RI.j] + m.RI.ARG);
	m.PC += 1;
	return m;
}


/**********************************************************
** instruction de soustraction
***********************************************************/

PSW cpu_SUB(PSW m) {
	m.AC = m.DR[m.RI.i] -= (m.DR[m.RI.j] + m.RI.ARG);
	m.PC += 1;
	return m;
}


/**********************************************************
** instruction de comparaison
***********************************************************/

PSW cpu_CMP(PSW m) {
	m.AC = (m.DR[m.RI.i] - (m.DR[m.RI.j] + m.RI.ARG));
	m.PC += 1;
	return m;
}

/**********************************************************
** instruction vide
***********************************************************/

PSW cpu_NOP(PSW cpu) {
	cpu.PC += 1;
	return cpu;
}

/**********************************************************
** instruction de test de positivité
***********************************************************/

PSW cpu_IFGT(PSW cpu) {
	if (cpu.AC > 0) cpu.PC = cpu.RI.ARG;
	else cpu.PC += 1;
	return cpu;
}

/**********************************************************
** instruction d'arret
***********************************************************/

PSW cpu_HALT(PSW cpu) {
	exit (1);
	return cpu;
}

/**********************************************************
** instruction de saut vers instruction
***********************************************************/

PSW cpu_JUMP(PSW cpu) {
	cpu.PC = cpu.RI.ARG;
	return cpu;
}


/**********************************************************
** instruction de saut vers instruction
***********************************************************/

PSW cpu_LOAD (PSW cpu) {
	cpu.AC = cpu.RI.j + cpu.RI.ARG;
	
	if (cpu.AC < 0 || cpu.AC >= cpu.SS) {
		cpu.IN = INT_SEGV;
		systeme (cpu);	
	}
	cpu.AC = mem[cpu.SB + cpu.AC];
	cpu.RI.i = cpu.AC;
	cpu.PC += 1;
	return cpu;
}


/**********************************************************
** instruction de sysc
***********************************************************/

PSW cpu_SYSC(PSW cpu) {
	cpu.IN = INT_SYS;
	return cpu;
}

/**********************************************************
** instruction store
***********************************************************/

PSW cpu_STORE(PSW cpu) {
	cpu.AC = cpu.RI.j + cpu.RI.ARG;
	
	if ((cpu.AC < 0) || (cpu.AC >= cpu.SS)) printf("erreur d'adressage mémoire cpu_STORE");
	
	mem[cpu.SB + cpu.AC] = cpu.RI.i;
	cpu.AC = cpu.RI.i;
	cpu.PC++;
		
	return cpu;
}

/**********************************************************
** Simulation de la CPU (mode utilisateur)
***********************************************************/

PSW cpu(PSW m) {
	
	/*** lecture et decodage de l'instruction ***/
	if (m.PC < 0 || m.PC >= m.SS) {
		m.IN = INT_SEGV;
		return (m);
	}
	m.RI = decode_instruction(mem[m.PC + m.SB]);
	
	/*** execution de l'instruction ***/
	switch (m.RI.OP) {
	case INST_ADD:
		m = cpu_ADD(m);
		break;
	case INST_SUB:
		m = cpu_SUB(m);
		break;
	case INST_CMP:
		m = cpu_CMP(m);
		break;
	case INST_IFGT:
		m = cpu_IFGT(m);
		break;
	case INST_NOP:
		m = cpu_NOP(m);
		break;
	case INST_JUMP:
		m = cpu_JUMP(m);
		break;
	case INST_HALT:
		m = cpu_HALT(m);
		break;
	case INST_LOAD:
		m = cpu_LOAD(m);
		break;
	case INST_SYSC:
		m = cpu_SYSC(m);
		break;
	case INST_STORE:
		m = cpu_STORE(m);
		break;
	default:
		/*** interruption instruction inconnue ***/
		m.IN = INT_INST;
		return (m);
	}
	if (m.IN == INT_SYS) return m;
	
	count = (count + 1) % 4;
	if (count == 0) {
		m.IN = INT_CLOCK;
	} else {
		m.IN = INT_TRACE;
	}

	/*** interruption apres chaque instruction ***/
	//m.IN = INT_TRACE;
	return m;
}



