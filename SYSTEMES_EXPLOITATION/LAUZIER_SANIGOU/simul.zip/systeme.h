
#ifndef __SYSTEM_H
#define __SYSTEM_H


/**********************************************************
** appel du systeme
***********************************************************/
PSW appel_systeme(PSW m);
PSW systeme(PSW m);

#endif

