#include <time.h>

#ifndef __SYSTEM_H
#define __SYSTEM_H


#define SYSC_PUTI   	(1)
#define SYSC_EXIT   	(2)
#define SYSC_NEW_THREAD	(3)
#define SYSC_SLEEP		(4)
#define SYSC_GETCHAR	(5)
#define SYSC_FORK		(6)

#define MAX_PROCESS  	(20)   /* nb maximum de processus  */

#define EMPTY        	(0)   /* processus non-pret       */
#define READY         	(1)   /* processus pret           */
#define SLEEP		 	(2)	  /* là il fait dodo		  */
#define GETCHAR			(3)

struct {
    PSW  cpu;               /* mot d'etat du processeur */
    int  state;             /* etat du processus        */
    }
    process[MAX_PROCESS];   /* table des processus      */

int current_process;   /* nu du processus courant  */



/**********************************************************
** appel du systeme
***********************************************************/

PSW systeme(PSW m);

#endif

