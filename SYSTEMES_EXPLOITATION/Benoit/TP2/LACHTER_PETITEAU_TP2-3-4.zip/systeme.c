#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "cpu.h"
#include "systeme.h"

time_t sleep_time[MAX_PROCESS];
time_t t;
int getchar_count = 0;
char tampon = '\0';

/**********************************************************
** Demarrage du systeme
***********************************************************/

static PSW systeme_init(void) {
	t = time(&t);
	
	int j;
	for(j = 0; j < MAX_PROCESS; j++)
		process[j].state = EMPTY;
	
	current_process = 0;
	process[current_process].state = READY;
	
	int i = 0;
	
	/*** creation d'un programme ***/
	make_inst(i++, INST_SUB, 1, 1, 0); 
	//make_inst(i++, INST_SUB, 2, 2, -1000);
	make_inst(i++, INST_SUB, 3, 3, -10);
	make_inst(i++, INST_CMP, 1, 2, 0);
	make_inst(i++, INST_IFGT, 0, 0, 10);
	make_inst(i++, INST_SYSC, 1, 0, SYSC_PUTI);
	make_inst(i++, INST_SYSC, 3 , 0, SYSC_SLEEP);
	make_inst(i++, INST_NOP, 0, 0, 0);
	make_inst(i++, INST_ADD, 1, 3, 0);
	make_inst(i++, INST_JUMP, 0, 0, 3);
	make_inst(i++, INST_HALT, 0, 0, 0);
	
	make_inst(i++, INST_SUB, 2, 2, -1000);
	make_inst(i++, INST_ADD, 1, 2, 500); 
	make_inst(i++, INST_SYSC, 1, 0, SYSC_NEW_THREAD);	
	make_inst(i++, INST_SYSC, 5, 0, SYSC_SLEEP);
	make_inst(i++, INST_ADD, 0, 2, 200); 
	make_inst(i++, INST_ADD, 0, 1, 100); 
	make_inst(i++, INST_SYSC, 1, 0, SYSC_PUTI);
	make_inst(i++, INST_SYSC, 0, 0, SYSC_EXIT);
	
	/*** valeur initiale du PSW ***/
	memset (&process[current_process].cpu, 0, sizeof(process[current_process].cpu));
	process[current_process].cpu.PC = 0;
	process[current_process].cpu.SB = 0;
	process[current_process].cpu.SS = 20;

	return process[current_process].cpu;
}

/**********************************************************
** Simulation du systeme (mode systeme)
***********************************************************/
PSW ordonnanceur(PSW m) {
	process[current_process].cpu = m;
	do {
		current_process = (current_process + 1) % MAX_PROCESS;
		if(process[current_process].state == SLEEP && sleep_time[current_process]<time(&t))
			process[current_process].state = READY;
		if(process[current_process].state == GETCHAR && tampon != '\0') {
			m.DR[m.RI.i] = tampon;
			tampon = '\0';
			m.PC++;
		}
	} while (process[current_process].state != READY);
	//printf("current process: %d\n", current_process);
	return process[current_process].cpu;
}

int new_thread_init(PSW m) {
	m.PC++;
	
	int i;
	for(i = 0; i < MAX_PROCESS; i++)
		if(process[i].state == EMPTY)
			break;
	
	if(i == MAX_PROCESS) {
		printf("[MAX_PROCESS] TROP DE PROCESSUS !!!!!!\n\n");
		return -1;
	}
	
	//printf("Création nouveau thread %d\n", i);
	process[i].cpu = m;
	process[i].state = READY;
	m.RI.i = i;
	m.AC = i;
	process[i].cpu.RI.i = 0;
	process[i].cpu.AC = 0;
	return i;
}

PSW new_thread(PSW m) {
	int i = new_thread_init(m);
	if(i == -1) return m;
	return process[i].cpu;
}

PSW new_fork(PSW m) {
	int i = new_thread_init(m);
	if(i == -1) return m;

	process[i].cpu.SB = MEM_SEG * i;

	int j;
	for(j = 0; j < MEM_SEG; j++)
		mem[i*MEM_SEG+j] = mem[current_process*MEM_SEG+j];
	
	return process[i].cpu;
}

PSW sysc_int(PSW m) {
	switch(m.RI.ARG) {
		case SYSC_EXIT:
			printf("[SYSC_EXIT]\n\tSortie du programme...\n\n");
			process[current_process].state = EMPTY;
			int i;
			int vide = 1;
			for(i = 0; i < MAX_PROCESS; i++)
				if(process[i].state == READY)
					vide = 0;
			if(vide == 1) exit(0);
			m = ordonnanceur(m);
			break;
		
		case SYSC_PUTI:
			printf("[SYSC_PUTI]\n\tRegistre : %d\n\n",m.DR[m.RI.i]);
			m.PC++;
			break;
		
		case SYSC_NEW_THREAD:
			printf("[SYSC_NEW_THREAD]\n\tCréation d'un nouveau thread\n\tPC : %d\n\tRI.i : %d\n\tDR : %d\n\n",
					current_process, m.RI.i, m.DR[m.RI.i]);
			m = new_thread(m);
			break;
		
		case SYSC_SLEEP:
			printf("[SYSC_SLEEP]\n\tProcessus %d endormi pendant %d secondes\n\n",current_process, m.RI.i);
			process[current_process].state = SLEEP;
			sleep_time[current_process] = time(&t) + m.RI.i;
			m.PC++;
			m = ordonnanceur(m);
			break;
		
		case SYSC_GETCHAR:
			printf("[SYSC_GETCHAR]\n\tPC : %d\n\n", m.PC);
			if(tampon != '\0') {
				m.DR[m.RI.i] = tampon;
				tampon = '\0';
				m.PC++;
			} else {
				process[current_process].state = GETCHAR;
				m = ordonnanceur(m);
			}
			break;
		
		case SYSC_FORK:
			printf("[SYSC_FORK]\n\tPC : %d\n\n", m.PC);
			m = new_fork(m);
			break;
	}
	return m;
}

PSW systeme(PSW m) {
	switch (m.IN) {
		case INT_INIT:
			printf("[INT_INST]\n\tPC : %d\n\n", m.PC);
			return systeme_init();
		
		case INT_SEGV:
			printf("[INT_SEGV]\n\tPC : %d\n\n", m.PC);
			exit(1);
		
		case INT_TRACE:
			printf("[INT_TRACE]\n\tPC : %d\n\tDR :", m.PC);
	        int i; for(i=0; i<8; i++) {
	        	if(i > 0) printf("\t    ");
	        	printf(" DR[%d] = %d\n", i, m.DR[i]);
	        }
	        printf("\n");
			break;
		
		case INT_INST:
			printf("[INT_SYSC]\n\tPC : %d\n\n", m.PC);
			exit(1);
		
		case INT_CLOCK:
			//printf("[INT_CLOCK]\n\n");
			m = ordonnanceur(m);
			break;
		
		case INT_SYSC:
			printf("[INT_SYSC]\n\tPC : %d\n\n", m.PC);
			m = sysc_int(m);
			break;
	}
	return m;
}
